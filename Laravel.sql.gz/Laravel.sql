-- Adminer 4.8.1 PostgreSQL 14.2 (Debian 14.2-1.pgdg110+1) dump

DROP TABLE IF EXISTS "failed_jobs";
DROP SEQUENCE IF EXISTS failed_jobs_id_seq;
CREATE SEQUENCE failed_jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."failed_jobs" (
    "id" bigint DEFAULT nextval('failed_jobs_id_seq') NOT NULL,
    "uuid" character varying(255) NOT NULL,
    "connection" text NOT NULL,
    "queue" text NOT NULL,
    "payload" text NOT NULL,
    "exception" text NOT NULL,
    "failed_at" timestamp(0) DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT "failed_jobs_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "failed_jobs_uuid_unique" UNIQUE ("uuid")
) WITH (oids = false);


DROP TABLE IF EXISTS "jobs";
DROP SEQUENCE IF EXISTS jobs_id_seq;
CREATE SEQUENCE jobs_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."jobs" (
    "id" bigint DEFAULT nextval('jobs_id_seq') NOT NULL,
    "queue" character varying(255) NOT NULL,
    "payload" text NOT NULL,
    "attempts" smallint NOT NULL,
    "reserved_at" integer,
    "available_at" integer NOT NULL,
    "created_at" integer NOT NULL,
    CONSTRAINT "jobs_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

CREATE INDEX "jobs_queue_index" ON "public"."jobs" USING btree ("queue");


DROP TABLE IF EXISTS "migrations";
DROP SEQUENCE IF EXISTS migrations_id_seq;
CREATE SEQUENCE migrations_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."migrations" (
    "id" integer DEFAULT nextval('migrations_id_seq') NOT NULL,
    "migration" character varying(255) NOT NULL,
    "batch" integer NOT NULL,
    CONSTRAINT "migrations_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "migrations" ("id", "migration", "batch") VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2022_03_01_081454_create_products_table',	1),
(5,	'2022_03_04_072432_create_roles_table',	1),
(6,	'2022_03_04_072538_create_role_user_table',	1),
(7,	'2022_03_04_072626_create_permissions_table',	1),
(8,	'2022_03_04_072708_create_permission_role_table',	1),
(9,	'2022_03_04_105936_create_statuses_table',	1);

DROP TABLE IF EXISTS "password_resets";
CREATE TABLE "public"."password_resets" (
    "email" character varying(255) NOT NULL,
    "token" character varying(255) NOT NULL,
    "created_at" timestamp(0)
) WITH (oids = false);

CREATE INDEX "password_resets_email_index" ON "public"."password_resets" USING btree ("email");


DROP TABLE IF EXISTS "permission_role";
DROP SEQUENCE IF EXISTS permission_role_id_seq;
CREATE SEQUENCE permission_role_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."permission_role" (
    "id" integer DEFAULT nextval('permission_role_id_seq') NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "role_id" integer DEFAULT '1' NOT NULL,
    "permission_id" integer DEFAULT '1' NOT NULL,
    CONSTRAINT "permission_role_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "permission_role" ("id", "created_at", "updated_at", "role_id", "permission_id") VALUES
(1,	NULL,	NULL,	1,	1),
(2,	NULL,	NULL,	1,	2),
(3,	NULL,	NULL,	1,	3),
(4,	NULL,	NULL,	1,	4),
(5,	NULL,	NULL,	2,	3);

DROP TABLE IF EXISTS "permissions";
DROP SEQUENCE IF EXISTS permissions_id_seq;
CREATE SEQUENCE permissions_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."permissions" (
    "id" integer DEFAULT nextval('permissions_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "permissions_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "permissions" ("id", "name", "created_at", "updated_at") VALUES
(1,	'ADD_PROD',	NULL,	NULL),
(2,	'UPDATE_ARTICLE',	NULL,	NULL),
(3,	'UPDATE_PROD',	NULL,	NULL),
(4,	'DELETE_PROD',	NULL,	NULL);

DROP TABLE IF EXISTS "products";
DROP SEQUENCE IF EXISTS products_id_seq;
CREATE SEQUENCE products_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."products" (
    "id" integer DEFAULT nextval('products_id_seq') NOT NULL,
    "ARTICLE" character varying(255) NOT NULL,
    "NAME" character varying(255) NOT NULL,
    "STATUS" character varying(255) NOT NULL,
    "DATA" jsonb,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    "deleted_at" timestamp(0),
    CONSTRAINT "products_article_unique" UNIQUE ("ARTICLE"),
    CONSTRAINT "products_pkey" PRIMARY KEY ("id")
) WITH (oids = false);


DROP TABLE IF EXISTS "role_user";
DROP SEQUENCE IF EXISTS role_user_id_seq;
CREATE SEQUENCE role_user_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."role_user" (
    "id" integer DEFAULT nextval('role_user_id_seq') NOT NULL,
    "user_id" integer DEFAULT '1' NOT NULL,
    "role_id" integer DEFAULT '1' NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "role_user_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "role_user" ("id", "user_id", "role_id", "created_at", "updated_at") VALUES
(1,	1,	1,	NULL,	NULL),
(3,	2,	3,	NULL,	NULL),
(4,	3,	2,	NULL,	NULL);

DROP TABLE IF EXISTS "roles";
DROP SEQUENCE IF EXISTS roles_id_seq;
CREATE SEQUENCE roles_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."roles" (
    "id" integer DEFAULT nextval('roles_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "roles" ("id", "name", "created_at", "updated_at") VALUES
(1,	'Admin',	NULL,	NULL),
(2,	'Moderator',	NULL,	NULL),
(3,	'Guest',	NULL,	NULL);

DROP TABLE IF EXISTS "statuses";
DROP SEQUENCE IF EXISTS statuses_id_seq;
CREATE SEQUENCE statuses_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1;

CREATE TABLE "public"."statuses" (
    "id" integer DEFAULT nextval('statuses_id_seq') NOT NULL,
    "NAME" character varying(255) NOT NULL,
    "STATUS" character varying(255) NOT NULL,
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "statuses_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "statuses" ("id", "NAME", "STATUS", "created_at", "updated_at") VALUES
(1,	'Доступен	',	'available',	NULL,	NULL),
(2,	'Не доступен	',	'unavailable',	NULL,	NULL);

DROP TABLE IF EXISTS "users";
DROP SEQUENCE IF EXISTS users_id_seq;
CREATE SEQUENCE users_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1;

CREATE TABLE "public"."users" (
    "id" bigint DEFAULT nextval('users_id_seq') NOT NULL,
    "name" character varying(255) NOT NULL,
    "login" character varying(255) NOT NULL,
    "email" character varying(255) NOT NULL,
    "email_verified_at" timestamp(0),
    "password" character varying(255) NOT NULL,
    "remember_token" character varying(100),
    "created_at" timestamp(0),
    "updated_at" timestamp(0),
    CONSTRAINT "users_email_unique" UNIQUE ("email"),
    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
) WITH (oids = false);

INSERT INTO "users" ("id", "name", "login", "email", "email_verified_at", "password", "remember_token", "created_at", "updated_at") VALUES
(1,	'admin',	'admin',	'liliabd08@rambler.ru',	NULL,	'$2y$10$4PAt8ev38sZC.gc3IjaRtuNY9odDFW1MCGp0uZ6MdDspm1ly9et9m',	NULL,	'2022-03-09 08:11:26',	'2022-03-09 08:11:26'),
(2,	'user',	'user',	'liliabd081@rambler.ru',	NULL,	'$2y$10$nR53YbB8u.aYPk/FsHXkfOBfjR5GKfYRKM8neQ9IkikPB41vavgVG',	NULL,	'2022-03-09 08:32:12',	'2022-03-09 08:32:12'),
(3,	'moser',	'moser',	'liliabd082@rambler.ru',	NULL,	'$2y$10$P7f/RvwDm31kfOCoY8945eYj9KUK2s37wKF0mq/Uvs/gNORofBj.i',	NULL,	'2022-03-09 08:32:53',	'2022-03-09 08:32:53');

ALTER TABLE ONLY "public"."permission_role" ADD CONSTRAINT "permission_role_permission_id_foreign" FOREIGN KEY (permission_id) REFERENCES permissions(id) NOT DEFERRABLE;
ALTER TABLE ONLY "public"."permission_role" ADD CONSTRAINT "permission_role_role_id_foreign" FOREIGN KEY (role_id) REFERENCES roles(id) NOT DEFERRABLE;

ALTER TABLE ONLY "public"."role_user" ADD CONSTRAINT "role_user_role_id_foreign" FOREIGN KEY (role_id) REFERENCES roles(id) NOT DEFERRABLE;
ALTER TABLE ONLY "public"."role_user" ADD CONSTRAINT "role_user_user_id_foreign" FOREIGN KEY (user_id) REFERENCES users(id) NOT DEFERRABLE;

-- 2022-03-10 15:28:16.993798+00
